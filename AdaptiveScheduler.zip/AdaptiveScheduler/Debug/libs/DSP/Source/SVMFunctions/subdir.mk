################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/SVMFunctions/SVMFunctions.c \
../libs/DSP/Source/SVMFunctions/SVMFunctionsF16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.c \
../libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.c \
../libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.c 

C_DEPS += \
./libs/DSP/Source/SVMFunctions/SVMFunctions.d \
./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.d \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.d \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.d 

OBJS += \
./libs/DSP/Source/SVMFunctions/SVMFunctions.o \
./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.o \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.o \
./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/SVMFunctions/%.o libs/DSP/Source/SVMFunctions/%.su libs/DSP/Source/SVMFunctions/%.cyclo: ../libs/DSP/Source/SVMFunctions/%.c libs/DSP/Source/SVMFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-SVMFunctions

clean-libs-2f-DSP-2f-Source-2f-SVMFunctions:
	-$(RM) ./libs/DSP/Source/SVMFunctions/SVMFunctions.cyclo ./libs/DSP/Source/SVMFunctions/SVMFunctions.d ./libs/DSP/Source/SVMFunctions/SVMFunctions.o ./libs/DSP/Source/SVMFunctions/SVMFunctions.su ./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.cyclo ./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.d ./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.o ./libs/DSP/Source/SVMFunctions/SVMFunctionsF16.su ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_linear_init_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_linear_predict_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_init_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_polynomial_predict_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_init_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_rbf_predict_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_init_f32.su ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.d ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.o ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f16.su ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.cyclo ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.d ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.o ./libs/DSP/Source/SVMFunctions/arm_svm_sigmoid_predict_f32.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-SVMFunctions

