################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.c \
../libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.c \
../libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.c 

C_DEPS += \
./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.d \
./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.d \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.d 

OBJS += \
./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.o \
./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.o \
./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/ComplexMathFunctions/%.o libs/DSP/Source/ComplexMathFunctions/%.su libs/DSP/Source/ComplexMathFunctions/%.cyclo: ../libs/DSP/Source/ComplexMathFunctions/%.c libs/DSP/Source/ComplexMathFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-ComplexMathFunctions

clean-libs-2f-DSP-2f-Source-2f-ComplexMathFunctions:
	-$(RM) ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.cyclo ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.d ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.o ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctions.su ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.cyclo ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.d ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.o ./libs/DSP/Source/ComplexMathFunctions/ComplexMathFunctionsF16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_conj_q31.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_dot_prod_q31.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_f64.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_fast_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_q31.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_f64.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mag_squared_q31.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.cyclo
	-$(RM) ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_f64.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_cmplx_q31.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f16.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_f32.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q15.su ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.cyclo ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.d ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.o ./libs/DSP/Source/ComplexMathFunctions/arm_cmplx_mult_real_q31.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-ComplexMathFunctions

