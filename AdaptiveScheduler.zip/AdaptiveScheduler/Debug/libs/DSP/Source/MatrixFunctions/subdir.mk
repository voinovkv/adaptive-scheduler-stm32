################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/MatrixFunctions/MatrixFunctions.c \
../libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.c \
../libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.c 

C_DEPS += \
./libs/DSP/Source/MatrixFunctions/MatrixFunctions.d \
./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.d \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.d 

OBJS += \
./libs/DSP/Source/MatrixFunctions/MatrixFunctions.o \
./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.o \
./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/MatrixFunctions/%.o libs/DSP/Source/MatrixFunctions/%.su libs/DSP/Source/MatrixFunctions/%.cyclo: ../libs/DSP/Source/MatrixFunctions/%.c libs/DSP/Source/MatrixFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-MatrixFunctions

clean-libs-2f-DSP-2f-Source-2f-MatrixFunctions:
	-$(RM) ./libs/DSP/Source/MatrixFunctions/MatrixFunctions.cyclo ./libs/DSP/Source/MatrixFunctions/MatrixFunctions.d ./libs/DSP/Source/MatrixFunctions/MatrixFunctions.o ./libs/DSP/Source/MatrixFunctions/MatrixFunctions.su ./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.cyclo ./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.d ./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.o ./libs/DSP/Source/MatrixFunctions/MatrixFunctionsF16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_add_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_add_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cholesky_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_mult_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_cmplx_trans_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_init_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_init_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_inverse_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_ldlt_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.cyclo
	-$(RM) ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_fast_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_opt_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.d ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.o ./libs/DSP/Source/MatrixFunctions/arm_mat_mult_q7.su ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_scale_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_lower_triangular_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_solve_upper_triangular_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_sub_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.d
	-$(RM) ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.d ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_f64.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.d ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.o ./libs/DSP/Source/MatrixFunctions/arm_mat_trans_q7.su ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.d ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.o ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f16.su ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.d ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.o ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_f32.su ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.d ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.o ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q15.su ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.d ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.o ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q31.su ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.cyclo ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.d ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.o ./libs/DSP/Source/MatrixFunctions/arm_mat_vec_mult_q7.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-MatrixFunctions

