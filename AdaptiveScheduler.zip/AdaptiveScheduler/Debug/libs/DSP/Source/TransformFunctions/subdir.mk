################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_UPPER_SRCS += \
../libs/DSP/Source/TransformFunctions/arm_bitreversal2.S 

C_SRCS += \
../libs/DSP/Source/TransformFunctions/TransformFunctions.c \
../libs/DSP/Source/TransformFunctions/TransformFunctionsF16.c \
../libs/DSP/Source/TransformFunctions/arm_bitreversal.c \
../libs/DSP/Source/TransformFunctions/arm_bitreversal2.c \
../libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_f64.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.c \
../libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_f32.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_q15.c \
../libs/DSP/Source/TransformFunctions/arm_dct4_q31.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_f16.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_f32.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_q15.c \
../libs/DSP/Source/TransformFunctions/arm_mfcc_q31.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_f32.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_q15.c \
../libs/DSP/Source/TransformFunctions/arm_rfft_q31.c 

C_DEPS += \
./libs/DSP/Source/TransformFunctions/TransformFunctions.d \
./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.d \
./libs/DSP/Source/TransformFunctions/arm_bitreversal.d \
./libs/DSP/Source/TransformFunctions/arm_bitreversal2.d \
./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_f64.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.d \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_f32.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_q15.d \
./libs/DSP/Source/TransformFunctions/arm_dct4_q31.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.d \
./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_f32.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_q15.d \
./libs/DSP/Source/TransformFunctions/arm_rfft_q31.d 

OBJS += \
./libs/DSP/Source/TransformFunctions/TransformFunctions.o \
./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.o \
./libs/DSP/Source/TransformFunctions/arm_bitreversal.o \
./libs/DSP/Source/TransformFunctions/arm_bitreversal2.o \
./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_f64.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.o \
./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_f32.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_q15.o \
./libs/DSP/Source/TransformFunctions/arm_dct4_q31.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.o \
./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_f32.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_q15.o \
./libs/DSP/Source/TransformFunctions/arm_rfft_q31.o 

S_UPPER_DEPS += \
./libs/DSP/Source/TransformFunctions/arm_bitreversal2.d 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/TransformFunctions/%.o libs/DSP/Source/TransformFunctions/%.su libs/DSP/Source/TransformFunctions/%.cyclo: ../libs/DSP/Source/TransformFunctions/%.c libs/DSP/Source/TransformFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
libs/DSP/Source/TransformFunctions/%.o: ../libs/DSP/Source/TransformFunctions/%.S libs/DSP/Source/TransformFunctions/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-libs-2f-DSP-2f-Source-2f-TransformFunctions

clean-libs-2f-DSP-2f-Source-2f-TransformFunctions:
	-$(RM) ./libs/DSP/Source/TransformFunctions/TransformFunctions.cyclo ./libs/DSP/Source/TransformFunctions/TransformFunctions.d ./libs/DSP/Source/TransformFunctions/TransformFunctions.o ./libs/DSP/Source/TransformFunctions/TransformFunctions.su ./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.cyclo ./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.d ./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.o ./libs/DSP/Source/TransformFunctions/TransformFunctionsF16.su ./libs/DSP/Source/TransformFunctions/arm_bitreversal.cyclo ./libs/DSP/Source/TransformFunctions/arm_bitreversal.d ./libs/DSP/Source/TransformFunctions/arm_bitreversal.o ./libs/DSP/Source/TransformFunctions/arm_bitreversal.su ./libs/DSP/Source/TransformFunctions/arm_bitreversal2.cyclo ./libs/DSP/Source/TransformFunctions/arm_bitreversal2.d ./libs/DSP/Source/TransformFunctions/arm_bitreversal2.o ./libs/DSP/Source/TransformFunctions/arm_bitreversal2.su ./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.d ./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.o ./libs/DSP/Source/TransformFunctions/arm_bitreversal_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_f64.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_f64.d ./libs/DSP/Source/TransformFunctions/arm_cfft_f64.o ./libs/DSP/Source/TransformFunctions/arm_cfft_f64.su ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.d ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.o ./libs/DSP/Source/TransformFunctions/arm_cfft_init_f64.su ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix2_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.cyclo
	-$(RM) ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q15.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix4_q31.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f16.su ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.d ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.o ./libs/DSP/Source/TransformFunctions/arm_cfft_radix8_f32.su ./libs/DSP/Source/TransformFunctions/arm_dct4_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_f32.d ./libs/DSP/Source/TransformFunctions/arm_dct4_f32.o ./libs/DSP/Source/TransformFunctions/arm_dct4_f32.su ./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_dct4_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_dct4_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_dct4_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_q15.d ./libs/DSP/Source/TransformFunctions/arm_dct4_q15.o ./libs/DSP/Source/TransformFunctions/arm_dct4_q15.su ./libs/DSP/Source/TransformFunctions/arm_dct4_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_dct4_q31.d ./libs/DSP/Source/TransformFunctions/arm_dct4_q31.o ./libs/DSP/Source/TransformFunctions/arm_dct4_q31.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_f16.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_f32.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f16.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_q15.su ./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.d ./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.o ./libs/DSP/Source/TransformFunctions/arm_mfcc_q31.su ./libs/DSP/Source/TransformFunctions/arm_rfft_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_f32.d ./libs/DSP/Source/TransformFunctions/arm_rfft_f32.o ./libs/DSP/Source/TransformFunctions/arm_rfft_f32.su ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f16.su ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f32.su ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_f64.su
	-$(RM) ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f16.su ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.d ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.o ./libs/DSP/Source/TransformFunctions/arm_rfft_fast_init_f64.su ./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.d ./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.o ./libs/DSP/Source/TransformFunctions/arm_rfft_init_f32.su ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.d ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.o ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q15.su ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.d ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.o ./libs/DSP/Source/TransformFunctions/arm_rfft_init_q31.su ./libs/DSP/Source/TransformFunctions/arm_rfft_q15.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_q15.d ./libs/DSP/Source/TransformFunctions/arm_rfft_q15.o ./libs/DSP/Source/TransformFunctions/arm_rfft_q15.su ./libs/DSP/Source/TransformFunctions/arm_rfft_q31.cyclo ./libs/DSP/Source/TransformFunctions/arm_rfft_q31.d ./libs/DSP/Source/TransformFunctions/arm_rfft_q31.o ./libs/DSP/Source/TransformFunctions/arm_rfft_q31.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-TransformFunctions

