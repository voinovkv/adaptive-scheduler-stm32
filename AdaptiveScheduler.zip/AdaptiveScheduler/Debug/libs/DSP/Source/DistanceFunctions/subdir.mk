################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/DistanceFunctions/DistanceFunctions.c \
../libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.c \
../libs/DSP/Source/DistanceFunctions/arm_boolean_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.c \
../libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.c \
../libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.c \
../libs/DSP/Source/DistanceFunctions/arm_dice_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.c \
../libs/DSP/Source/DistanceFunctions/arm_hamming_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.c \
../libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.c \
../libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.c \
../libs/DSP/Source/DistanceFunctions/arm_yule_distance.c 

C_DEPS += \
./libs/DSP/Source/DistanceFunctions/DistanceFunctions.d \
./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.d \
./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.d \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.d \
./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.d \
./libs/DSP/Source/DistanceFunctions/arm_dice_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.d \
./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.d \
./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.d \
./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.d \
./libs/DSP/Source/DistanceFunctions/arm_yule_distance.d 

OBJS += \
./libs/DSP/Source/DistanceFunctions/DistanceFunctions.o \
./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.o \
./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.o \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.o \
./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.o \
./libs/DSP/Source/DistanceFunctions/arm_dice_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.o \
./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.o \
./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.o \
./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.o \
./libs/DSP/Source/DistanceFunctions/arm_yule_distance.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/DistanceFunctions/%.o libs/DSP/Source/DistanceFunctions/%.su libs/DSP/Source/DistanceFunctions/%.cyclo: ../libs/DSP/Source/DistanceFunctions/%.c libs/DSP/Source/DistanceFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-DistanceFunctions

clean-libs-2f-DSP-2f-Source-2f-DistanceFunctions:
	-$(RM) ./libs/DSP/Source/DistanceFunctions/DistanceFunctions.cyclo ./libs/DSP/Source/DistanceFunctions/DistanceFunctions.d ./libs/DSP/Source/DistanceFunctions/DistanceFunctions.o ./libs/DSP/Source/DistanceFunctions/DistanceFunctions.su ./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.cyclo ./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.d ./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.o ./libs/DSP/Source/DistanceFunctions/DistanceFunctionsF16.su ./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.d ./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.o ./libs/DSP/Source/DistanceFunctions/arm_boolean_distance.su ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_braycurtis_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_canberra_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.cyclo ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.d ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.o ./libs/DSP/Source/DistanceFunctions/arm_chebyshev_distance_f64.su ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.d ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.o ./libs/DSP/Source/DistanceFunctions/arm_cityblock_distance_f64.su ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_correlation_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.cyclo ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.d ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.o ./libs/DSP/Source/DistanceFunctions/arm_cosine_distance_f64.su ./libs/DSP/Source/DistanceFunctions/arm_dice_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_dice_distance.d ./libs/DSP/Source/DistanceFunctions/arm_dice_distance.o ./libs/DSP/Source/DistanceFunctions/arm_dice_distance.su ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.cyclo ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.d ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.o ./libs/DSP/Source/DistanceFunctions/arm_euclidean_distance_f64.su ./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.d ./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.o ./libs/DSP/Source/DistanceFunctions/arm_hamming_distance.su ./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.cyclo
	-$(RM) ./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.d ./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.o ./libs/DSP/Source/DistanceFunctions/arm_jaccard_distance.su ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_jensenshannon_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.d ./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.o ./libs/DSP/Source/DistanceFunctions/arm_kulsinski_distance.su ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.cyclo ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.d ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.o ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f16.su ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.cyclo ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.d ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.o ./libs/DSP/Source/DistanceFunctions/arm_minkowski_distance_f32.su ./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.d ./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.o ./libs/DSP/Source/DistanceFunctions/arm_rogerstanimoto_distance.su ./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.d ./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.o ./libs/DSP/Source/DistanceFunctions/arm_russellrao_distance.su ./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.d ./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.o ./libs/DSP/Source/DistanceFunctions/arm_sokalmichener_distance.su ./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.d ./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.o ./libs/DSP/Source/DistanceFunctions/arm_sokalsneath_distance.su ./libs/DSP/Source/DistanceFunctions/arm_yule_distance.cyclo ./libs/DSP/Source/DistanceFunctions/arm_yule_distance.d ./libs/DSP/Source/DistanceFunctions/arm_yule_distance.o ./libs/DSP/Source/DistanceFunctions/arm_yule_distance.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-DistanceFunctions

