################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.c \
../libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_abs_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_add_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_and_u16.c \
../libs/DSP/Source/BasicMathFunctions/arm_and_u32.c \
../libs/DSP/Source/BasicMathFunctions/arm_and_u8.c \
../libs/DSP/Source/BasicMathFunctions/arm_clip_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_clip_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_clip_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_clip_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_clip_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_mult_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_negate_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_not_u16.c \
../libs/DSP/Source/BasicMathFunctions/arm_not_u32.c \
../libs/DSP/Source/BasicMathFunctions/arm_not_u8.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_offset_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_or_u16.c \
../libs/DSP/Source/BasicMathFunctions/arm_or_u32.c \
../libs/DSP/Source/BasicMathFunctions/arm_or_u8.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_scale_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_shift_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_shift_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_shift_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_f16.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_f32.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_f64.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_q15.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_q31.c \
../libs/DSP/Source/BasicMathFunctions/arm_sub_q7.c \
../libs/DSP/Source/BasicMathFunctions/arm_xor_u16.c \
../libs/DSP/Source/BasicMathFunctions/arm_xor_u32.c \
../libs/DSP/Source/BasicMathFunctions/arm_xor_u8.c 

C_DEPS += \
./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.d \
./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_add_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_and_u16.d \
./libs/DSP/Source/BasicMathFunctions/arm_and_u32.d \
./libs/DSP/Source/BasicMathFunctions/arm_and_u8.d \
./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_not_u16.d \
./libs/DSP/Source/BasicMathFunctions/arm_not_u32.d \
./libs/DSP/Source/BasicMathFunctions/arm_not_u8.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_or_u16.d \
./libs/DSP/Source/BasicMathFunctions/arm_or_u32.d \
./libs/DSP/Source/BasicMathFunctions/arm_or_u8.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.d \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.d \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.d \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.d \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.d 

OBJS += \
./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.o \
./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_add_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_and_u16.o \
./libs/DSP/Source/BasicMathFunctions/arm_and_u32.o \
./libs/DSP/Source/BasicMathFunctions/arm_and_u8.o \
./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_not_u16.o \
./libs/DSP/Source/BasicMathFunctions/arm_not_u32.o \
./libs/DSP/Source/BasicMathFunctions/arm_not_u8.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_or_u16.o \
./libs/DSP/Source/BasicMathFunctions/arm_or_u32.o \
./libs/DSP/Source/BasicMathFunctions/arm_or_u8.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.o \
./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.o \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.o \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.o \
./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/BasicMathFunctions/%.o libs/DSP/Source/BasicMathFunctions/%.su libs/DSP/Source/BasicMathFunctions/%.cyclo: ../libs/DSP/Source/BasicMathFunctions/%.c libs/DSP/Source/BasicMathFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-BasicMathFunctions

clean-libs-2f-DSP-2f-Source-2f-BasicMathFunctions:
	-$(RM) ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.cyclo ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.d ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.o ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctions.su ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.cyclo ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.d ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.o ./libs/DSP/Source/BasicMathFunctions/BasicMathFunctionsF16.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_abs_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_add_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_add_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_add_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_add_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_add_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_add_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_add_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_add_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_add_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_add_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_add_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_add_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_add_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_add_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_add_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_add_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_add_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_add_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_add_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_and_u16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_and_u16.d ./libs/DSP/Source/BasicMathFunctions/arm_and_u16.o ./libs/DSP/Source/BasicMathFunctions/arm_and_u16.su ./libs/DSP/Source/BasicMathFunctions/arm_and_u32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_and_u32.d ./libs/DSP/Source/BasicMathFunctions/arm_and_u32.o ./libs/DSP/Source/BasicMathFunctions/arm_and_u32.su ./libs/DSP/Source/BasicMathFunctions/arm_and_u8.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_and_u8.d ./libs/DSP/Source/BasicMathFunctions/arm_and_u8.o ./libs/DSP/Source/BasicMathFunctions/arm_and_u8.su ./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_clip_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_clip_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_clip_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_clip_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_clip_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.o
	-$(RM) ./libs/DSP/Source/BasicMathFunctions/arm_dot_prod_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_mult_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_negate_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_not_u16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_not_u16.d ./libs/DSP/Source/BasicMathFunctions/arm_not_u16.o ./libs/DSP/Source/BasicMathFunctions/arm_not_u16.su ./libs/DSP/Source/BasicMathFunctions/arm_not_u32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_not_u32.d ./libs/DSP/Source/BasicMathFunctions/arm_not_u32.o ./libs/DSP/Source/BasicMathFunctions/arm_not_u32.su ./libs/DSP/Source/BasicMathFunctions/arm_not_u8.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_not_u8.d ./libs/DSP/Source/BasicMathFunctions/arm_not_u8.o ./libs/DSP/Source/BasicMathFunctions/arm_not_u8.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_offset_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_or_u16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_or_u16.d ./libs/DSP/Source/BasicMathFunctions/arm_or_u16.o ./libs/DSP/Source/BasicMathFunctions/arm_or_u16.su ./libs/DSP/Source/BasicMathFunctions/arm_or_u32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_or_u32.d ./libs/DSP/Source/BasicMathFunctions/arm_or_u32.o ./libs/DSP/Source/BasicMathFunctions/arm_or_u32.su ./libs/DSP/Source/BasicMathFunctions/arm_or_u8.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_or_u8.d ./libs/DSP/Source/BasicMathFunctions/arm_or_u8.o ./libs/DSP/Source/BasicMathFunctions/arm_or_u8.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.d
	-$(RM) ./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_scale_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_shift_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_shift_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_shift_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_f16.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_f32.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_f64.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_q15.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_q31.su ./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.d ./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.o ./libs/DSP/Source/BasicMathFunctions/arm_sub_q7.su ./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.d ./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.o ./libs/DSP/Source/BasicMathFunctions/arm_xor_u16.su ./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.d ./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.o ./libs/DSP/Source/BasicMathFunctions/arm_xor_u32.su ./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.cyclo ./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.d ./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.o ./libs/DSP/Source/BasicMathFunctions/arm_xor_u8.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-BasicMathFunctions

