################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/SupportFunctions/SupportFunctions.c \
../libs/DSP/Source/SupportFunctions/SupportFunctionsF16.c \
../libs/DSP/Source/SupportFunctions/arm_barycenter_f16.c \
../libs/DSP/Source/SupportFunctions/arm_barycenter_f32.c \
../libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_copy_f16.c \
../libs/DSP/Source/SupportFunctions/arm_copy_f32.c \
../libs/DSP/Source/SupportFunctions/arm_copy_f64.c \
../libs/DSP/Source/SupportFunctions/arm_copy_q15.c \
../libs/DSP/Source/SupportFunctions/arm_copy_q31.c \
../libs/DSP/Source/SupportFunctions/arm_copy_q7.c \
../libs/DSP/Source/SupportFunctions/arm_f16_to_float.c \
../libs/DSP/Source/SupportFunctions/arm_f16_to_q15.c \
../libs/DSP/Source/SupportFunctions/arm_fill_f16.c \
../libs/DSP/Source/SupportFunctions/arm_fill_f32.c \
../libs/DSP/Source/SupportFunctions/arm_fill_f64.c \
../libs/DSP/Source/SupportFunctions/arm_fill_q15.c \
../libs/DSP/Source/SupportFunctions/arm_fill_q31.c \
../libs/DSP/Source/SupportFunctions/arm_fill_q7.c \
../libs/DSP/Source/SupportFunctions/arm_float_to_f16.c \
../libs/DSP/Source/SupportFunctions/arm_float_to_q15.c \
../libs/DSP/Source/SupportFunctions/arm_float_to_q31.c \
../libs/DSP/Source/SupportFunctions/arm_float_to_q7.c \
../libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.c \
../libs/DSP/Source/SupportFunctions/arm_q15_to_f16.c \
../libs/DSP/Source/SupportFunctions/arm_q15_to_float.c \
../libs/DSP/Source/SupportFunctions/arm_q15_to_q31.c \
../libs/DSP/Source/SupportFunctions/arm_q15_to_q7.c \
../libs/DSP/Source/SupportFunctions/arm_q31_to_float.c \
../libs/DSP/Source/SupportFunctions/arm_q31_to_q15.c \
../libs/DSP/Source/SupportFunctions/arm_q31_to_q7.c \
../libs/DSP/Source/SupportFunctions/arm_q7_to_float.c \
../libs/DSP/Source/SupportFunctions/arm_q7_to_q15.c \
../libs/DSP/Source/SupportFunctions/arm_q7_to_q31.c \
../libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_sort_f32.c \
../libs/DSP/Source/SupportFunctions/arm_sort_init_f32.c \
../libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.c \
../libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.c 

C_DEPS += \
./libs/DSP/Source/SupportFunctions/SupportFunctions.d \
./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.d \
./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.d \
./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.d \
./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_copy_f16.d \
./libs/DSP/Source/SupportFunctions/arm_copy_f32.d \
./libs/DSP/Source/SupportFunctions/arm_copy_f64.d \
./libs/DSP/Source/SupportFunctions/arm_copy_q15.d \
./libs/DSP/Source/SupportFunctions/arm_copy_q31.d \
./libs/DSP/Source/SupportFunctions/arm_copy_q7.d \
./libs/DSP/Source/SupportFunctions/arm_f16_to_float.d \
./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.d \
./libs/DSP/Source/SupportFunctions/arm_fill_f16.d \
./libs/DSP/Source/SupportFunctions/arm_fill_f32.d \
./libs/DSP/Source/SupportFunctions/arm_fill_f64.d \
./libs/DSP/Source/SupportFunctions/arm_fill_q15.d \
./libs/DSP/Source/SupportFunctions/arm_fill_q31.d \
./libs/DSP/Source/SupportFunctions/arm_fill_q7.d \
./libs/DSP/Source/SupportFunctions/arm_float_to_f16.d \
./libs/DSP/Source/SupportFunctions/arm_float_to_q15.d \
./libs/DSP/Source/SupportFunctions/arm_float_to_q31.d \
./libs/DSP/Source/SupportFunctions/arm_float_to_q7.d \
./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.d \
./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.d \
./libs/DSP/Source/SupportFunctions/arm_q15_to_float.d \
./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.d \
./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.d \
./libs/DSP/Source/SupportFunctions/arm_q31_to_float.d \
./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.d \
./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.d \
./libs/DSP/Source/SupportFunctions/arm_q7_to_float.d \
./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.d \
./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.d \
./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_sort_f32.d \
./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.d \
./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.d \
./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.d 

OBJS += \
./libs/DSP/Source/SupportFunctions/SupportFunctions.o \
./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.o \
./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.o \
./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.o \
./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_copy_f16.o \
./libs/DSP/Source/SupportFunctions/arm_copy_f32.o \
./libs/DSP/Source/SupportFunctions/arm_copy_f64.o \
./libs/DSP/Source/SupportFunctions/arm_copy_q15.o \
./libs/DSP/Source/SupportFunctions/arm_copy_q31.o \
./libs/DSP/Source/SupportFunctions/arm_copy_q7.o \
./libs/DSP/Source/SupportFunctions/arm_f16_to_float.o \
./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.o \
./libs/DSP/Source/SupportFunctions/arm_fill_f16.o \
./libs/DSP/Source/SupportFunctions/arm_fill_f32.o \
./libs/DSP/Source/SupportFunctions/arm_fill_f64.o \
./libs/DSP/Source/SupportFunctions/arm_fill_q15.o \
./libs/DSP/Source/SupportFunctions/arm_fill_q31.o \
./libs/DSP/Source/SupportFunctions/arm_fill_q7.o \
./libs/DSP/Source/SupportFunctions/arm_float_to_f16.o \
./libs/DSP/Source/SupportFunctions/arm_float_to_q15.o \
./libs/DSP/Source/SupportFunctions/arm_float_to_q31.o \
./libs/DSP/Source/SupportFunctions/arm_float_to_q7.o \
./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.o \
./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.o \
./libs/DSP/Source/SupportFunctions/arm_q15_to_float.o \
./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.o \
./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.o \
./libs/DSP/Source/SupportFunctions/arm_q31_to_float.o \
./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.o \
./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.o \
./libs/DSP/Source/SupportFunctions/arm_q7_to_float.o \
./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.o \
./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.o \
./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_sort_f32.o \
./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.o \
./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.o \
./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/SupportFunctions/%.o libs/DSP/Source/SupportFunctions/%.su libs/DSP/Source/SupportFunctions/%.cyclo: ../libs/DSP/Source/SupportFunctions/%.c libs/DSP/Source/SupportFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-SupportFunctions

clean-libs-2f-DSP-2f-Source-2f-SupportFunctions:
	-$(RM) ./libs/DSP/Source/SupportFunctions/SupportFunctions.cyclo ./libs/DSP/Source/SupportFunctions/SupportFunctions.d ./libs/DSP/Source/SupportFunctions/SupportFunctions.o ./libs/DSP/Source/SupportFunctions/SupportFunctions.su ./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.cyclo ./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.d ./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.o ./libs/DSP/Source/SupportFunctions/SupportFunctionsF16.su ./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.d ./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.o ./libs/DSP/Source/SupportFunctions/arm_barycenter_f16.su ./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.d ./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.o ./libs/DSP/Source/SupportFunctions/arm_barycenter_f32.su ./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_bitonic_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_bubble_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_copy_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_f16.d ./libs/DSP/Source/SupportFunctions/arm_copy_f16.o ./libs/DSP/Source/SupportFunctions/arm_copy_f16.su ./libs/DSP/Source/SupportFunctions/arm_copy_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_f32.d ./libs/DSP/Source/SupportFunctions/arm_copy_f32.o ./libs/DSP/Source/SupportFunctions/arm_copy_f32.su ./libs/DSP/Source/SupportFunctions/arm_copy_f64.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_f64.d ./libs/DSP/Source/SupportFunctions/arm_copy_f64.o ./libs/DSP/Source/SupportFunctions/arm_copy_f64.su ./libs/DSP/Source/SupportFunctions/arm_copy_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_q15.d ./libs/DSP/Source/SupportFunctions/arm_copy_q15.o ./libs/DSP/Source/SupportFunctions/arm_copy_q15.su ./libs/DSP/Source/SupportFunctions/arm_copy_q31.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_q31.d ./libs/DSP/Source/SupportFunctions/arm_copy_q31.o ./libs/DSP/Source/SupportFunctions/arm_copy_q31.su ./libs/DSP/Source/SupportFunctions/arm_copy_q7.cyclo ./libs/DSP/Source/SupportFunctions/arm_copy_q7.d ./libs/DSP/Source/SupportFunctions/arm_copy_q7.o ./libs/DSP/Source/SupportFunctions/arm_copy_q7.su ./libs/DSP/Source/SupportFunctions/arm_f16_to_float.cyclo ./libs/DSP/Source/SupportFunctions/arm_f16_to_float.d ./libs/DSP/Source/SupportFunctions/arm_f16_to_float.o ./libs/DSP/Source/SupportFunctions/arm_f16_to_float.su ./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.d ./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.o ./libs/DSP/Source/SupportFunctions/arm_f16_to_q15.su ./libs/DSP/Source/SupportFunctions/arm_fill_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_f16.d ./libs/DSP/Source/SupportFunctions/arm_fill_f16.o ./libs/DSP/Source/SupportFunctions/arm_fill_f16.su ./libs/DSP/Source/SupportFunctions/arm_fill_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_f32.d ./libs/DSP/Source/SupportFunctions/arm_fill_f32.o ./libs/DSP/Source/SupportFunctions/arm_fill_f32.su ./libs/DSP/Source/SupportFunctions/arm_fill_f64.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_f64.d ./libs/DSP/Source/SupportFunctions/arm_fill_f64.o ./libs/DSP/Source/SupportFunctions/arm_fill_f64.su ./libs/DSP/Source/SupportFunctions/arm_fill_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_q15.d ./libs/DSP/Source/SupportFunctions/arm_fill_q15.o ./libs/DSP/Source/SupportFunctions/arm_fill_q15.su ./libs/DSP/Source/SupportFunctions/arm_fill_q31.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_q31.d ./libs/DSP/Source/SupportFunctions/arm_fill_q31.o ./libs/DSP/Source/SupportFunctions/arm_fill_q31.su ./libs/DSP/Source/SupportFunctions/arm_fill_q7.cyclo ./libs/DSP/Source/SupportFunctions/arm_fill_q7.d ./libs/DSP/Source/SupportFunctions/arm_fill_q7.o ./libs/DSP/Source/SupportFunctions/arm_fill_q7.su ./libs/DSP/Source/SupportFunctions/arm_float_to_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_float_to_f16.d ./libs/DSP/Source/SupportFunctions/arm_float_to_f16.o ./libs/DSP/Source/SupportFunctions/arm_float_to_f16.su ./libs/DSP/Source/SupportFunctions/arm_float_to_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_float_to_q15.d ./libs/DSP/Source/SupportFunctions/arm_float_to_q15.o ./libs/DSP/Source/SupportFunctions/arm_float_to_q15.su ./libs/DSP/Source/SupportFunctions/arm_float_to_q31.cyclo ./libs/DSP/Source/SupportFunctions/arm_float_to_q31.d ./libs/DSP/Source/SupportFunctions/arm_float_to_q31.o ./libs/DSP/Source/SupportFunctions/arm_float_to_q31.su ./libs/DSP/Source/SupportFunctions/arm_float_to_q7.cyclo ./libs/DSP/Source/SupportFunctions/arm_float_to_q7.d ./libs/DSP/Source/SupportFunctions/arm_float_to_q7.o ./libs/DSP/Source/SupportFunctions/arm_float_to_q7.su ./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_heap_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_insertion_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_merge_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.d
	-$(RM) ./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.o ./libs/DSP/Source/SupportFunctions/arm_merge_sort_init_f32.su ./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.d ./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.o ./libs/DSP/Source/SupportFunctions/arm_q15_to_f16.su ./libs/DSP/Source/SupportFunctions/arm_q15_to_float.cyclo ./libs/DSP/Source/SupportFunctions/arm_q15_to_float.d ./libs/DSP/Source/SupportFunctions/arm_q15_to_float.o ./libs/DSP/Source/SupportFunctions/arm_q15_to_float.su ./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.cyclo ./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.d ./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.o ./libs/DSP/Source/SupportFunctions/arm_q15_to_q31.su ./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.cyclo ./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.d ./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.o ./libs/DSP/Source/SupportFunctions/arm_q15_to_q7.su ./libs/DSP/Source/SupportFunctions/arm_q31_to_float.cyclo ./libs/DSP/Source/SupportFunctions/arm_q31_to_float.d ./libs/DSP/Source/SupportFunctions/arm_q31_to_float.o ./libs/DSP/Source/SupportFunctions/arm_q31_to_float.su ./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.d ./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.o ./libs/DSP/Source/SupportFunctions/arm_q31_to_q15.su ./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.cyclo ./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.d ./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.o ./libs/DSP/Source/SupportFunctions/arm_q31_to_q7.su ./libs/DSP/Source/SupportFunctions/arm_q7_to_float.cyclo ./libs/DSP/Source/SupportFunctions/arm_q7_to_float.d ./libs/DSP/Source/SupportFunctions/arm_q7_to_float.o ./libs/DSP/Source/SupportFunctions/arm_q7_to_float.su ./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.cyclo ./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.d ./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.o ./libs/DSP/Source/SupportFunctions/arm_q7_to_q15.su ./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.cyclo ./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.d ./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.o ./libs/DSP/Source/SupportFunctions/arm_q7_to_q31.su ./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_quick_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_selection_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_sort_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_sort_f32.d ./libs/DSP/Source/SupportFunctions/arm_sort_f32.o ./libs/DSP/Source/SupportFunctions/arm_sort_f32.su ./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.d ./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.o ./libs/DSP/Source/SupportFunctions/arm_sort_init_f32.su ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.cyclo ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.d ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.o ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f16.su ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.cyclo ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.d ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.o ./libs/DSP/Source/SupportFunctions/arm_weighted_sum_f32.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-SupportFunctions

