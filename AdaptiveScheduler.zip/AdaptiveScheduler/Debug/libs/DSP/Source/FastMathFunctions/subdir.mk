################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/Source/FastMathFunctions/FastMathFunctions.c \
../libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.c \
../libs/DSP/Source/FastMathFunctions/arm_atan2_f16.c \
../libs/DSP/Source/FastMathFunctions/arm_atan2_f32.c \
../libs/DSP/Source/FastMathFunctions/arm_atan2_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_atan2_q31.c \
../libs/DSP/Source/FastMathFunctions/arm_cos_f32.c \
../libs/DSP/Source/FastMathFunctions/arm_cos_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_cos_q31.c \
../libs/DSP/Source/FastMathFunctions/arm_divide_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_divide_q31.c \
../libs/DSP/Source/FastMathFunctions/arm_sin_f32.c \
../libs/DSP/Source/FastMathFunctions/arm_sin_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_sin_q31.c \
../libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.c \
../libs/DSP/Source/FastMathFunctions/arm_vexp_f16.c \
../libs/DSP/Source/FastMathFunctions/arm_vexp_f32.c \
../libs/DSP/Source/FastMathFunctions/arm_vexp_f64.c \
../libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.c \
../libs/DSP/Source/FastMathFunctions/arm_vlog_f16.c \
../libs/DSP/Source/FastMathFunctions/arm_vlog_f32.c \
../libs/DSP/Source/FastMathFunctions/arm_vlog_f64.c \
../libs/DSP/Source/FastMathFunctions/arm_vlog_q15.c \
../libs/DSP/Source/FastMathFunctions/arm_vlog_q31.c 

C_DEPS += \
./libs/DSP/Source/FastMathFunctions/FastMathFunctions.d \
./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.d \
./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.d \
./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.d \
./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.d \
./libs/DSP/Source/FastMathFunctions/arm_cos_f32.d \
./libs/DSP/Source/FastMathFunctions/arm_cos_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_cos_q31.d \
./libs/DSP/Source/FastMathFunctions/arm_divide_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_divide_q31.d \
./libs/DSP/Source/FastMathFunctions/arm_sin_f32.d \
./libs/DSP/Source/FastMathFunctions/arm_sin_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_sin_q31.d \
./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.d \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.d \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.d \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.d \
./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.d \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.d \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.d \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.d \
./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.d \
./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.d 

OBJS += \
./libs/DSP/Source/FastMathFunctions/FastMathFunctions.o \
./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.o \
./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.o \
./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.o \
./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.o \
./libs/DSP/Source/FastMathFunctions/arm_cos_f32.o \
./libs/DSP/Source/FastMathFunctions/arm_cos_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_cos_q31.o \
./libs/DSP/Source/FastMathFunctions/arm_divide_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_divide_q31.o \
./libs/DSP/Source/FastMathFunctions/arm_sin_f32.o \
./libs/DSP/Source/FastMathFunctions/arm_sin_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_sin_q31.o \
./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.o \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.o \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.o \
./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.o \
./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.o \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.o \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.o \
./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.o \
./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.o \
./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/Source/FastMathFunctions/%.o libs/DSP/Source/FastMathFunctions/%.su libs/DSP/Source/FastMathFunctions/%.cyclo: ../libs/DSP/Source/FastMathFunctions/%.c libs/DSP/Source/FastMathFunctions/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-Source-2f-FastMathFunctions

clean-libs-2f-DSP-2f-Source-2f-FastMathFunctions:
	-$(RM) ./libs/DSP/Source/FastMathFunctions/FastMathFunctions.cyclo ./libs/DSP/Source/FastMathFunctions/FastMathFunctions.d ./libs/DSP/Source/FastMathFunctions/FastMathFunctions.o ./libs/DSP/Source/FastMathFunctions/FastMathFunctions.su ./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.cyclo ./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.d ./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.o ./libs/DSP/Source/FastMathFunctions/FastMathFunctionsF16.su ./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.cyclo ./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.d ./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.o ./libs/DSP/Source/FastMathFunctions/arm_atan2_f16.su ./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.cyclo ./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.d ./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.o ./libs/DSP/Source/FastMathFunctions/arm_atan2_f32.su ./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.d ./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.o ./libs/DSP/Source/FastMathFunctions/arm_atan2_q15.su ./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.d ./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.o ./libs/DSP/Source/FastMathFunctions/arm_atan2_q31.su ./libs/DSP/Source/FastMathFunctions/arm_cos_f32.cyclo ./libs/DSP/Source/FastMathFunctions/arm_cos_f32.d ./libs/DSP/Source/FastMathFunctions/arm_cos_f32.o ./libs/DSP/Source/FastMathFunctions/arm_cos_f32.su ./libs/DSP/Source/FastMathFunctions/arm_cos_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_cos_q15.d ./libs/DSP/Source/FastMathFunctions/arm_cos_q15.o ./libs/DSP/Source/FastMathFunctions/arm_cos_q15.su ./libs/DSP/Source/FastMathFunctions/arm_cos_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_cos_q31.d ./libs/DSP/Source/FastMathFunctions/arm_cos_q31.o ./libs/DSP/Source/FastMathFunctions/arm_cos_q31.su ./libs/DSP/Source/FastMathFunctions/arm_divide_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_divide_q15.d ./libs/DSP/Source/FastMathFunctions/arm_divide_q15.o ./libs/DSP/Source/FastMathFunctions/arm_divide_q15.su ./libs/DSP/Source/FastMathFunctions/arm_divide_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_divide_q31.d ./libs/DSP/Source/FastMathFunctions/arm_divide_q31.o ./libs/DSP/Source/FastMathFunctions/arm_divide_q31.su ./libs/DSP/Source/FastMathFunctions/arm_sin_f32.cyclo ./libs/DSP/Source/FastMathFunctions/arm_sin_f32.d ./libs/DSP/Source/FastMathFunctions/arm_sin_f32.o ./libs/DSP/Source/FastMathFunctions/arm_sin_f32.su ./libs/DSP/Source/FastMathFunctions/arm_sin_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_sin_q15.d ./libs/DSP/Source/FastMathFunctions/arm_sin_q15.o ./libs/DSP/Source/FastMathFunctions/arm_sin_q15.su ./libs/DSP/Source/FastMathFunctions/arm_sin_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_sin_q31.d ./libs/DSP/Source/FastMathFunctions/arm_sin_q31.o ./libs/DSP/Source/FastMathFunctions/arm_sin_q31.su ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.d ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.o ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q15.su ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.d ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.o ./libs/DSP/Source/FastMathFunctions/arm_sqrt_q31.su ./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.d ./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.o ./libs/DSP/Source/FastMathFunctions/arm_vexp_f16.su ./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.d ./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.o ./libs/DSP/Source/FastMathFunctions/arm_vexp_f32.su ./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.d ./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.o ./libs/DSP/Source/FastMathFunctions/arm_vexp_f64.su ./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.d ./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.o ./libs/DSP/Source/FastMathFunctions/arm_vinverse_f16.su ./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.d ./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.o ./libs/DSP/Source/FastMathFunctions/arm_vlog_f16.su ./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.d ./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.o ./libs/DSP/Source/FastMathFunctions/arm_vlog_f32.su ./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.d ./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.o ./libs/DSP/Source/FastMathFunctions/arm_vlog_f64.su ./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.d ./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.o ./libs/DSP/Source/FastMathFunctions/arm_vlog_q15.su ./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.cyclo ./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.d ./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.o ./libs/DSP/Source/FastMathFunctions/arm_vlog_q31.su

.PHONY: clean-libs-2f-DSP-2f-Source-2f-FastMathFunctions

