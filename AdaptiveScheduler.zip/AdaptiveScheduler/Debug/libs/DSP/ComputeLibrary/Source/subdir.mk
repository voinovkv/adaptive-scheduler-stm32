################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/DSP/ComputeLibrary/Source/arm_cl_tables.c 

C_DEPS += \
./libs/DSP/ComputeLibrary/Source/arm_cl_tables.d 

OBJS += \
./libs/DSP/ComputeLibrary/Source/arm_cl_tables.o 


# Each subdirectory must supply rules for building sources it contributes
libs/DSP/ComputeLibrary/Source/%.o libs/DSP/ComputeLibrary/Source/%.su libs/DSP/ComputeLibrary/Source/%.cyclo: ../libs/DSP/ComputeLibrary/Source/%.c libs/DSP/ComputeLibrary/Source/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F401xC -DARM_MATH_CM4 -D__FPU_PRESENT -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/Include" -I"C:/ST/STM32CubeIDE_1.19.0/AdaptiveScheduler/libs/DSP/PrivateInclude" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-libs-2f-DSP-2f-ComputeLibrary-2f-Source

clean-libs-2f-DSP-2f-ComputeLibrary-2f-Source:
	-$(RM) ./libs/DSP/ComputeLibrary/Source/arm_cl_tables.cyclo ./libs/DSP/ComputeLibrary/Source/arm_cl_tables.d ./libs/DSP/ComputeLibrary/Source/arm_cl_tables.o ./libs/DSP/ComputeLibrary/Source/arm_cl_tables.su

.PHONY: clean-libs-2f-DSP-2f-ComputeLibrary-2f-Source

