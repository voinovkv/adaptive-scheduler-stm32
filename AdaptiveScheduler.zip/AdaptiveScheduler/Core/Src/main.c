/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.cpp
  * @brief          : Адаптивный планировщик нагрузки для STM32F401CCU6 (C)
  * @note           : Кварц 25 МГц, PLL -> 84 МГц, FreeRTOS CMSIS-RTOS v2
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os2.h"          // CMSIS-RTOS v2
#include <string.h>
#include <stdio.h>
#include <stdint.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// Структура для хранения информации о модуле
typedef struct {
    void (*func)(void);
    const char* name;
    uint32_t last_cycles;
    uint32_t base_weight;
    uint32_t current_weight;
    uint32_t energy_cost;
    uint32_t skip_counter;
} ModuleInfo;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define NUM_MODULES         4
#define IDEAL_CYCLES        50000
#define MAX_WEIGHT          255
#define MIN_WEIGHT          1
#define SKIP_THRESHOLD      5
#define ADAPT_PERIOD        10
/* USER CODE END PD */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = osPriorityNormal,
};

osThreadId_t schedulerTaskHandle;
const osThreadAttr_t schedulerTask_attributes = {
  .name = "schedulerTask",
  .stack_size = 512 * 4,
  .priority = osPriorityHigh3,
};

osThreadId_t monitorTaskHandle;
const osThreadAttr_t monitorTask_attributes = {
  .name = "monitorTask",
  .stack_size = 512 * 4,
  .priority = osPriorityLow,
};

/* USER CODE BEGIN PV */
static ModuleInfo modules[NUM_MODULES];
static uint8_t adapt_counter = 0;
static osMutexId_t modulesMutex;   // Мьютекс для защиты массива modules (CMSIS-RTOS v2)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
void StartDefaultTask(void *argument);

#ifdef __cplusplus
extern "C" {
#endif
void DWT_Init(void);
uint32_t DWT_GetCycleCount(void);
void Monitor_ExecuteModule(ModuleInfo* module);
void Scheduler_Init(void);
void Scheduler_RunOnce(void);
void UpdateWeights(uint32_t executed_idx);
void UART_SendString(const char* str);
void FFT_Module(void);
void PID_Module(void);
void AES_Module(void);
void Kalman_Module(void);
void StartSchedulerTask(void *argument);
void StartMonitorTask(void *argument);
#ifdef __cplusplus
}
#endif

/* USER CODE BEGIN 0 */
#ifdef __cplusplus
extern "C" {
#endif

void FFT_Module(void) {
    for(uint32_t i=0; i<400000; i++) __NOP();
}

void PID_Module(void) {
    for(uint32_t i=0; i<50000; i++) __NOP();
}

void AES_Module(void) {
    for(uint32_t i=0; i<250000; i++) __NOP();
}

void Kalman_Module(void) {
    for(uint32_t i=0; i<80000; i++) __NOP();
}

void DWT_Init(void) {
    if (!(CoreDebug->DEMCR & CoreDebug_DEMCR_TRCENA_Msk)) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    }
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

uint32_t DWT_GetCycleCount(void) {
    return DWT->CYCCNT;
}

void Monitor_ExecuteModule(ModuleInfo* module) {
    uint32_t start = DWT_GetCycleCount();
    module->func();
    uint32_t end = DWT_GetCycleCount();
    // Корректная обработка переполнения 32-битного счётчика
    if (end >= start) {
        module->last_cycles = end - start;
    } else {
        module->last_cycles = (0xFFFFFFFFU - start) + end + 1;
    }
}

void Scheduler_Init(void) {
    modules[0] = (ModuleInfo){FFT_Module,   "FFT",    IDEAL_CYCLES, 100, 100, 80, 0};
    modules[1] = (ModuleInfo){PID_Module,   "PID",    IDEAL_CYCLES, 80,  80,  30, 0};
    modules[2] = (ModuleInfo){AES_Module,   "AES",    IDEAL_CYCLES, 70,  70,  90, 0};
    modules[3] = (ModuleInfo){Kalman_Module,"Kalman", IDEAL_CYCLES, 60,  60,  40, 0};
}

void UpdateWeights(uint32_t executed_idx) {
    // Вызывается внутри захваченного мьютекса
    uint32_t cycles = modules[executed_idx].last_cycles;
    if (cycles == 0) cycles = 1;

    uint32_t new_weight = modules[executed_idx].base_weight * IDEAL_CYCLES / cycles;

    if (new_weight < MIN_WEIGHT) new_weight = MIN_WEIGHT;
    if (new_weight > MAX_WEIGHT) new_weight = MAX_WEIGHT;

    // Учёт энергозатрат: вычитаем 1/25 от energy_cost (целочисленно)
    uint32_t energy_penalty = modules[executed_idx].energy_cost / 25;
    if (new_weight > energy_penalty)
        new_weight -= energy_penalty;
    else
        new_weight = MIN_WEIGHT;

    if (new_weight < MIN_WEIGHT) new_weight = MIN_WEIGHT;
    if (new_weight > MAX_WEIGHT) new_weight = MAX_WEIGHT;

    modules[executed_idx].current_weight = new_weight;
}

void Scheduler_RunOnce(void) {
    int best_idx = 0;
    uint64_t best_score = 0;

    // ---- 1. Выбор лучшего модуля под защитой мьютекса ----
    osMutexAcquire(modulesMutex, osWaitForever);
    for (int i = 0; i < NUM_MODULES; i++) {
        uint32_t denom = modules[i].last_cycles + 1;
        uint64_t score = (uint64_t)modules[i].current_weight * 1000000 / denom;
        if (score > best_score) {
            best_score = score;
            best_idx = i;
        }
    }
    // Сохраняем указатель на выбранный модуль (сам массив ещё не изменится)
    ModuleInfo* selected = &modules[best_idx];
    osMutexRelease(modulesMutex);

    // ---- 2. Выполнение модуля (без мьютекса) ----
    Monitor_ExecuteModule(selected);

    // ---- 3. Обновление статистики под защитой мьютекса ----
    osMutexAcquire(modulesMutex, osWaitForever);
    // Инкремент счетчиков пропусков и сброс для выполненного модуля
    adapt_counter++;
    modules[best_idx].skip_counter = 0;
    for (int i = 0; i < NUM_MODULES; i++) {
        if (i != best_idx) {
            modules[i].skip_counter++;
        }
    }
    // Периодическая адаптация весов
    if (adapt_counter >= ADAPT_PERIOD) {
        UpdateWeights(best_idx);
        adapt_counter = 0;
    }
    osMutexRelease(modulesMutex);
}

void UART_SendString(const char* str) {
    HAL_UART_Transmit(&huart2, (uint8_t*)str, strlen(str), 100);
}

void StartDefaultTask(void *argument) {
    (void)argument;
    for (;;) osDelay(100);  // ничего не делает, можно удалить
}

void StartSchedulerTask(void *argument) {
    (void)argument;
    for (;;) {
        Scheduler_RunOnce();
        osDelay(50);        // задержка в тиках ОС (при configTICK_RATE_HZ=1000 == 50 мс)
    }
}

void StartMonitorTask(void *argument) {
    (void)argument;
    char json_buf[512];
    uint32_t fft_cyc, pid_cyc, aes_cyc, kal_cyc;
    uint32_t fft_w, pid_w, aes_w, kal_w;
    uint32_t fft_skip, pid_skip, aes_skip, kal_skip;

    for (;;) {
        // Защищённое чтение данных из modules
        osMutexAcquire(modulesMutex, osWaitForever);
        fft_cyc   = modules[0].last_cycles;
        fft_w     = modules[0].current_weight;
        fft_skip  = modules[0].skip_counter;
        pid_cyc   = modules[1].last_cycles;
        pid_w     = modules[1].current_weight;
        pid_skip  = modules[1].skip_counter;
        aes_cyc   = modules[2].last_cycles;
        aes_w     = modules[2].current_weight;
        aes_skip  = modules[2].skip_counter;
        kal_cyc   = modules[3].last_cycles;
        kal_w     = modules[3].current_weight;
        kal_skip  = modules[3].skip_counter;
        osMutexRelease(modulesMutex);

        snprintf(json_buf, sizeof(json_buf),
            "{"
            "\"FFT\":{\"cyc\":%lu,\"w\":%lu,\"skip\":%lu},"
            "\"PID\":{\"cyc\":%lu,\"w\":%lu,\"skip\":%lu},"
            "\"AES\":{\"cyc\":%lu,\"w\":%lu,\"skip\":%lu},"
            "\"Kalman\":{\"cyc\":%lu,\"w\":%lu,\"skip\":%lu}"
            "}\r\n",
            fft_cyc, fft_w, fft_skip,
            pid_cyc, pid_w, pid_skip,
            aes_cyc, aes_w, aes_skip,
            kal_cyc, kal_w, kal_skip);
        UART_SendString(json_buf);

        osDelay(1000);
    }
}

#ifdef __cplusplus
}
#endif
/* USER CODE END 0 */

/**
  * @brief  Initialization of USART2 MSP (MCU Support Package)
  * @note   Реализация HAL_UART_MspInit/DeInit находится в stm32f4xx_hal_msp.c
  *         (сгенерировано CubeMX). Дублировать их здесь не нужно.
  */

int main(void) {
    SCB->CPACR |= ((3UL << 10*2) | (3UL << 11*2));
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_USART2_UART_Init();
    DWT_Init();
    Scheduler_Init();

    osKernelInitialize();

    // Создание мьютекса после инициализации ядра
    modulesMutex = osMutexNew(NULL);
    if (modulesMutex == NULL) {
        Error_Handler();  // недостаточно ресурсов
    }

    defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);
    schedulerTaskHandle = osThreadNew(StartSchedulerTask, NULL, &schedulerTask_attributes);
    monitorTaskHandle = osThreadNew(StartMonitorTask, NULL, &monitorTask_attributes);

    osKernelStart();

    while (1) { /* RTOS runs */ }
}

void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = 25;
    RCC_OscInitStruct.PLL.PLLN = 336;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ = 4;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
}

static void MX_USART2_UART_Init(void) {
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void) {
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void Error_Handler(void) {
    __disable_irq();
    while (1) {}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {
    (void)file;
    (void)line;
}
#endif
